=======
Authors
=======

Development Leads
-----------------

-   Ivan Bojer (@ivanbojer)
-   Garfield Lee Freeman (@shinmog)


Contributors
------------

-   Robert Hagen (@rnh556)
-   Luigi Mori (@jtschichold)
-   Vinay Venkataraghavan (@vinayvenkat)
-   Michael Richardson (@mrichardson03)
-   Joshua Colson (@freakinhippie)


Credits
-------

Thank you Kevin Steves, creator of the `pan-python <https://github.com/kevinsteves/pan-python>`_ library.

Also, big high-five to Brian Torres-Gil, creator of the `pan-os-python <https://github.com/PaloAltoNetworks/pan-os-python>`_ library.