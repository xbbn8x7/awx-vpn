=======
License
=======

.. include:: ../../LICENSE