===============
Release History
===============

For a complete release history, see the `GitHub releases page <https://github.com/PaloAltoNetworks/pan-os-ansible/releases>`_ for the repository.