---
name: Documentation problem
about: A typo, inaccuracy, or improvement in the documentation
title: ''
labels: documentation
assignees: ''

---

## Documentation link

<!--- Where is the documentation with the issue? -->

## Describe the problem

<!--- Is this a typo, stale information, request for improvement, inaccuracy? -->
<!--- Clearly and concisely describe the problem with the documentation -->

## Suggested fix

<!--- If possible, help us by offering a suggested fix to the problem -->
